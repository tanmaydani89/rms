package runway_management_system.runway_management_system;

import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.FileNotFoundException;

import com.rms.service.MapDataService;

import org.junit.jupiter.api.Test;
//import junit.framework.Test;
//import junit.framework.TestCase;
//import junit.framework.TestSuite;


public class MapDataServiceTest {
	
	private MapDataService mapDataService;

    @Test
    public void testApp()
    {
    	try {
			mapDataService.getCountriesWithMaxAirports();
		} catch (IllegalStateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        assertTrue( true );
    }
}
