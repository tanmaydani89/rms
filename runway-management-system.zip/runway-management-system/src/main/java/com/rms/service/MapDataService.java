package com.rms.service;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import com.opencsv.bean.CsvToBeanBuilder;
import com.rms.dto.Airport;
import com.rms.dto.Country;
import com.rms.dto.Runway;

public class MapDataService {

	public List<Country> getAllCountries() throws IllegalStateException, FileNotFoundException {
		String fileName = "E:\\Workspace\\runway-management-system\\resources\\countries.csv";

        List<Country> countries = new CsvToBeanBuilder<Country>(new FileReader(fileName))
                .withType(Country.class)
                .build()
                .parse();

        countries.forEach(System.out::println);
        return countries;
	}
	
	public List<Runway> getAllRunways() throws IllegalStateException, FileNotFoundException {
		String fileName = "E:\\Workspace\\runway-management-system\\resources\\runways.csv";

        List<Runway> runways = new CsvToBeanBuilder<Runway>(new FileReader(fileName))
                .withType(Runway.class)
                .build()
                .parse();

        runways.forEach(System.out::println);
        return runways;
	}
	
	public List<Airport> getAllAirports() throws IllegalStateException, FileNotFoundException {
		String fileName = "E:\\Workspace\\runway-management-system\\resources\\airports.csv";

        List<Airport> airports = new CsvToBeanBuilder<Airport>(new FileReader(fileName))
                .withType(Airport.class)
                .build()
                .parse();

        airports.forEach(System.out::println);
        return airports;
	}

	public List<String> getCountriesWithMaxAirports() throws IllegalStateException, FileNotFoundException {
		// TODO Auto-generated method stub
		List<Country> allCountries = getAllCountries();
		List<Airport> airports = getAllAirports();
		
		Map<String, Integer> airportCountMap = new HashMap<>(); 
		for (Country country : allCountries) {
			int count = 0;
			for (Airport airport : airports) {
            if  (country.getCode().equals(airport.getIsoCountry())) {
            	count++;
            }
		}
			airportCountMap.put(country.getCode(), count);
        }
		
		Map<String, Integer>  sortedMap = airportCountMap.entrySet()
				.stream()
				.sorted(Collections.reverseOrder(Map.Entry.comparingByValue()))
				.collect( 
						Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue, (e1, e2) -> e2, LinkedHashMap::new));
		
	   System.out.println("map after sorting by values in descending order: " + sortedMap);

	   List<String> topTenCountries = new LinkedList<>(); 
			   
			   sortedMap.entrySet()
			   .stream()
			   .forEach(countryCode -> topTenCountries.add(countryCode.getKey()));
			   
		topTenCountries.subList(10, topTenCountries.size()).clear();
		
		   System.out.println("List after sorting by values in final list: " + topTenCountries);

		return topTenCountries;
	}
	
	
}
