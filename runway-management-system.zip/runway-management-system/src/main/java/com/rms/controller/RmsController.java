package com.rms.controller;

import java.io.FileNotFoundException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.rms.dto.Airport;
import com.rms.dto.Country;
import com.rms.service.MapDataService;

@RestController
public class RmsController {

	@Autowired
	MapDataService mapDataService;
	
	@GetMapping(value = "/top-ten-countries")
	public ResponseEntity<List<String>> getTopCountries() throws IllegalStateException, FileNotFoundException {
        return new ResponseEntity<>(mapDataService.getCountriesWithMaxAirports(), HttpStatus.OK);
	}
}
