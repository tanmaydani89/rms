package com.rms.dto;

import com.opencsv.bean.CsvBindByName;

public class Country {
	
	@CsvBindByName(column = "id")
    private Integer id;
	
	@CsvBindByName(column = "code")
    private String code;
	
	@CsvBindByName(column = "name")
    private String name;
	
	@CsvBindByName(column = "continent")
    private String continent;
	
	@CsvBindByName(column = "wikipedia_link")
    private String wikipediaLink;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getContinent() {
		return continent;
	}

	public void setContinent(String continent) {
		this.continent = continent;
	}

	public String getWikipediaLink() {
		return wikipediaLink;
	}

	public void setWikipediaLink(String wikipediaLink) {
		this.wikipediaLink = wikipediaLink;
	}

	@Override
	public String toString() {
		return "Country [id=" + id + ", code=" + code + ", name=" + name + ", continent=" + continent
				+ ", wikipediaLink=" + wikipediaLink + "]";
	}

} 