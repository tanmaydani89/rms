package com.rms.dto;

import com.opencsv.bean.CsvBindByName;

public class Runway {
	
    @CsvBindByName(column = "id")
    private String id;
    
    @CsvBindByName(column = "airport_ref")
    private String airportRef;
    
    @CsvBindByName(column = "airport_ident")
    private String airportIdent;
    
    @CsvBindByName(column = "length_ft")
    private String length; 
    
    @CsvBindByName(column = "width_ft")
    private String width;
    
    @CsvBindByName(column = "surface")
    private String surface;
    
    @CsvBindByName(column = "lighted")
    private String isLighted;
    
    @CsvBindByName(column = "closed")
    private String isClosed;
    
    @CsvBindByName(column = "le_ident")
    private String leIdent;
    
    @CsvBindByName(column = "le_latitude_deg")
    private String leLatitude;
    
    @CsvBindByName(column = "le_longitude_deg")
    private String leLongitude;
    
    @CsvBindByName(column = "le_elevation_ft")
    private String leElevation;
    
    @CsvBindByName(column = "le_heading_deg")
    private String leHeading;
    
    @CsvBindByName(column = "le_displaced_threshold_ft")
    private String threshold;
    
    @CsvBindByName(column = "he_ident")
    private String heIdent;
    
    @CsvBindByName(column = "he_latitude_deg")
    private String heLatitude;
    
    @CsvBindByName(column = "he_longitude_deg")
    private String heLongitude;
    
    @CsvBindByName(column = "he_elevation_ft")
    private String heElevation;
    
    @CsvBindByName(column = "he_heading_degT")
    private String heHeading;	
    
    @CsvBindByName(column = "he_displaced_threshold_ft")
    private String heThreshold;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getAirportRef() {
		return airportRef;
	}

	public void setAirportRef(String airportRef) {
		this.airportRef = airportRef;
	}

	public String getAirportIdent() {
		return airportIdent;
	}

	public void setAirportIdent(String airportIdent) {
		this.airportIdent = airportIdent;
	}

	public String getLength() {
		return length;
	}

	public void setLength(String length) {
		this.length = length;
	}

	public String getWidth() {
		return width;
	}

	public void setWidth(String width) {
		this.width = width;
	}

	public String getSurface() {
		return surface;
	}

	public void setSurface(String surface) {
		this.surface = surface;
	}

	public String isLighted() {
		return isLighted;
	}

	public void setLighted(String isLighted) {
		this.isLighted = isLighted;
	}

	public String isClosed() {
		return isClosed;
	}

	public void setClosed(String isClosed) {
		this.isClosed = isClosed;
	}

	public String getLeIdent() {
		return leIdent;
	}

	public void setLeIdent(String leIdent) {
		this.leIdent = leIdent;
	}

	public String getLeLatitude() {
		return leLatitude;
	}

	public void setLeLatitude(String leLatitude) {
		this.leLatitude = leLatitude;
	}

	public String getLeLongitude() {
		return leLongitude;
	}

	public void setLeLongitude(String leLongitude) {
		this.leLongitude = leLongitude;
	}

	public String getLeElevation() {
		return leElevation;
	}

	public void setLeElevation(String leElevation) {
		this.leElevation = leElevation;
	}

	public String getLeHeading() {
		return leHeading;
	}

	public void setLeHeading(String leHeading) {
		this.leHeading = leHeading;
	}

	public String getThreshold() {
		return threshold;
	}

	public void setThreshold(String threshold) {
		this.threshold = threshold;
	}

	public String getHeIdent() {
		return heIdent;
	}

	public void setHeIdent(String heIdent) {
		this.heIdent = heIdent;
	}

	public String getHeLatitude() {
		return heLatitude;
	}

	public void setHeLatitude(String heLatitude) {
		this.heLatitude = heLatitude;
	}

	public String getHeLongitude() {
		return heLongitude;
	}

	public void setHeLongitude(String heLongitude) {
		this.heLongitude = heLongitude;
	}

	public String getHeElevation() {
		return heElevation;
	}

	public void setHeElevation(String heElevation) {
		this.heElevation = heElevation;
	}

	public String getHeHeading() {
		return heHeading;
	}

	public void setHeHeading(String heHeading) {
		this.heHeading = heHeading;
	}

	public String getHeThreshold() {
		return heThreshold;
	}

	public void setHeThreshold(String heThreshold) {
		this.heThreshold = heThreshold;
	}

	@Override
	public String toString() {
		return "Country [id=" + id + ", airportRef=" + airportRef + ", airportIdent=" + airportIdent + ", length="
				+ length + ", width=" + width + ", surface=" + surface + ", isLighted=" + isLighted + ", isClosed="
				+ isClosed + ", leIdent=" + leIdent + ", leLatitude=" + leLatitude + ", leLongitude=" + leLongitude
				+ ", leElevation=" + leElevation + ", leHeading=" + leHeading + ", threshold=" + threshold
				+ ", heIdent=" + heIdent + ", heLatitude=" + heLatitude + ", heLongitude=" + heLongitude
				+ ", heElevation=" + heElevation + ", heHeading=" + heHeading + ", heThreshold=" + heThreshold + "]";
	}
}
