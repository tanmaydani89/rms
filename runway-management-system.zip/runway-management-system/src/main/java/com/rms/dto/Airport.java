package com.rms.dto;

import com.opencsv.bean.CsvBindByName;

public class Airport {
	@CsvBindByName(column = "id")
    private Integer id;
	
	@CsvBindByName(column = "ident")
    private String ident;
	
	@CsvBindByName(column = "type")
    private String type;
	
	@CsvBindByName(column = "name")
    private String name;
	
	@CsvBindByName(column = "latitude_deg")
    private String latitude;
	
	@CsvBindByName(column = "longitude_deg")
    private String longitude;
	
	@CsvBindByName(column = "elevation_ft")
    private String elevation;
	
	@CsvBindByName(column = "continent")
    private String continent;
	
	@CsvBindByName(column = "iso_country")
    private String isoCountry;
	
	@CsvBindByName(column = "iso_region")
    private String isoRegion;
	
	@CsvBindByName(column = "municipality")
    private String municipality;
	
	@CsvBindByName(column = "scheduled_service")
    private String scheduledService;
	
	@CsvBindByName(column = "gps_code")
    private String gpsCode;
	
	@CsvBindByName(column = "iata_code")
    private String iataCode;
	
	@CsvBindByName(column = "local_code")
    private String localCode;
	
	@CsvBindByName(column = "home_link")
    private String homeLink;
	
	@CsvBindByName(column = "wikipedia_link")
    private String wikipediaLink;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getIdent() {
		return ident;
	}

	public void setIdent(String ident) {
		this.ident = ident;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getLatitude() {
		return latitude;
	}

	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}

	public String getLongitude() {
		return longitude;
	}

	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}

	public String getElevation() {
		return elevation;
	}

	public void setElevation(String elevation) {
		this.elevation = elevation;
	}

	public String getContinent() {
		return continent;
	}

	public void setContinent(String continent) {
		this.continent = continent;
	}

	public String getIsoCountry() {
		return isoCountry;
	}

	public void setIsoCountry(String isoCountry) {
		this.isoCountry = isoCountry;
	}

	public String getIsoRegion() {
		return isoRegion;
	}

	public void setIsoRegion(String isoRegion) {
		this.isoRegion = isoRegion;
	}

	public String getMunicipality() {
		return municipality;
	}

	public void setMunicipality(String municipality) {
		this.municipality = municipality;
	}

	public String getScheduledService() {
		return scheduledService;
	}

	public void setScheduledService(String scheduledService) {
		this.scheduledService = scheduledService;
	}

	public String getGpsCode() {
		return gpsCode;
	}

	public void setGpsCode(String gpsCode) {
		this.gpsCode = gpsCode;
	}

	public String getIataCode() {
		return iataCode;
	}

	public void setIataCode(String iataCode) {
		this.iataCode = iataCode;
	}

	public String getLocalCode() {
		return localCode;
	}

	public void setLocalCode(String localCode) {
		this.localCode = localCode;
	}

	public String getHomeLink() {
		return homeLink;
	}

	public void setHomeLink(String homeLink) {
		this.homeLink = homeLink;
	}

	public String getWikipediaLink() {
		return wikipediaLink;
	}

	public void setWikipediaLink(String wikipediaLink) {
		this.wikipediaLink = wikipediaLink;
	}

	@Override
	public String toString() {
		return "Airport [id=" + id + ", ident=" + ident + ", type=" + type + ", name=" + name + ", latitude=" + latitude
				+ ", longitude=" + longitude + ", elevation=" + elevation + ", continent=" + continent + ", isoCountry="
				+ isoCountry + ", isoRegion=" + isoRegion + ", municipality=" + municipality + ", scheduledService="
				+ scheduledService + ", gpsCode=" + gpsCode + ", iataCode=" + iataCode + ", localCode=" + localCode
				+ ", homeLink=" + homeLink + ", wikipediaLink=" + wikipediaLink + "]";
	}
	
}
