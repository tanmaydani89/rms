package com.rms;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.List;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.opencsv.bean.CsvToBeanBuilder;
import com.rms.controller.RmsController;
import com.rms.dto.Country;

@SpringBootApplication
public class SampleApplication {

    public static void main(String[] args){
//    	RmsController rmsController = new RmsController();;
//    	try {
//			rmsController.getTopCountries();
//		} catch (IllegalStateException | FileNotFoundException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
        SpringApplication.run(SampleApplication.class, args);
    }

}